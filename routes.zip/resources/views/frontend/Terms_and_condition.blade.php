@extends('frontend.layouts.master')
@section('css')
<style>
  
</style>
@endsection
@section('content')
{!! $privacy->terms !!}
@endsection